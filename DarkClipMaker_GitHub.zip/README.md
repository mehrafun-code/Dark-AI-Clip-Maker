# Dark Clip Maker

YouTube link -> best clips -> 9:16 Reels/Shorts (captions ke saath).

## .exe kaise milega (GitHub se)
1. Is repository ke **Actions** tab mein jao.
2. **Build Windows EXE** -> **Run workflow**.
3. 10-20 minute baad green tick aane par us run mein neeche **Artifacts** se `DarkClipMaker-Windows` download karo.
4. Zip extract karo aur `DarkClipMaker.exe` double click karo.

## Python se chalana (bina exe)
`run.bat` double click (Python + FFmpeg install hona chahiye).

Sirf apni ya permission wali videos use karo (copyright).
